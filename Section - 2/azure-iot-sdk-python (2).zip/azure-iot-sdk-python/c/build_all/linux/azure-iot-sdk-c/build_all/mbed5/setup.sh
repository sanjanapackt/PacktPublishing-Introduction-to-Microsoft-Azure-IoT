sudo apt-get update && apt-get install -y \
curl \
git \
python-software-properties \
build-essential \
pkg-config
sudo curl -sL https://deb.nodesource.com/setup_6.x | bash -
sudo apt-get install -y nodejs
